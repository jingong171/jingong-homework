from random import randint
import pygal
class Die():
    """表示一个骰子的类"""
    def __init__(self,num_sides = 6):
         """骰子默认为六面"""
         self.num_sides = num_sides

    def roll(self):
        """返回一个位于1和骰子面数之间的随机数值"""
        return randint(1,self.num_sides)
die1 = Die()
die2 = Die(10)
results = []
for roll_num in range(10000):
    result = die1.roll()*die2.roll()
    results.append(result)

max_result = die1.num_sides*die2.num_sides
frequencies = []
for value in range(1,max_result + 1):
    frequency = results.count(value)
    frequencies.append(frequency)

hist = pygal.Bar()
hist.title = 'Result of Rolling D6 and D10 dice 10000 Times'
hist.x_labels = [x for x in range(1,61)]
hist.x_title = "Result"
hist.y_labels = "Frequency of Result"
hist.add('D6+D10',frequencies)
hist.render_to_file('dice_visual.svg')
     
