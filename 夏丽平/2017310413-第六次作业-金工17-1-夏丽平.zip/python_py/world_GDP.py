import json
import pygal
from pygal_maps_world.i18n import COUNTRIES
#将数据下载下来
filename = 'gdp_json.json'
with open(filename) as f:
    pop_data = json.load(f)
#建立一个字典，用于保存GDP和国家
    
##for pop_dict in pop_data:
##    if pop_dict['Year'] == 2010:
##        country_name = pop_dict['Country Name']
##        GDP = float(pop_dict['Value'])
##        print(country_name,GDP)

##for country_code in sorted(COUNTRIES.keys()):
##    print(country_code,COUNTRIES[country_code])
##print(COUNTRIES)

def get_country_code(country_name):
    """返回两位的国别编码"""
    for code1, name in COUNTRIES.items():
        if name == country_name:
            return code1
        return None  
cc_gdp = {}
for pop_dict in pop_data:
    if pop_dict['Year'] == 2010:
        country_name = pop_dict['Country Name']
        GDP = int(float(pop_dict['Value']))
        code = get_country_code(country_name)
        if code == None:
            print('error-'+country_name)
        else:
            cc_gdp[code] = GDP
print(cc_gdp)
cc_gdps1,cc_gdps2,cc_gdps3 = {},{},{}
for cc, gdp in cc_gdp.items():
    if gdp<1000000000:
        cc_gdps1[cc] = gdp
    elif gdp<10000000000:
        cc_gdps2[cc] = gdp
    else:
        cc_gdps3[cc] = gdp
        
#看一下每一个阶段有多少个国家
print(len(cc_gdps1),len(cc_gdps2),len(cc_gdps3))
wm = pygal.maps.world.World()
wm.title = 'World GDP in 2010,by Country'
wm.add('0-1bn',cc_gdps1)
wm.add('1bn-10bn',cc_gdps2)
wm.add('>10bn',cc_gdps3)
wm.render_to_file('world_gdp.svg')

