import csv
import json
import matplotlib.pyplot as plt
#将各个CSV文件之中的名字读取
ids,name,classes,counts=[],[],[],[]
filename1 = 'pythonsign_20181009.csv'
with open(filename1) as f1:
    reader = csv.reader(f1)
    for row in reader:
        try:
            id1=int(row[0])
            name1 = row[1]
            class1 =  row[3]
        except ValueError:
            pass
        else:
            ids.append(id1)
            name.append(name1)
            classes.append(class1)
            counts.append(1)
filename2 = 'pythonsign_20181030.csv'
with open(filename2) as f2:
    reader = csv.reader(f2)
    for row in reader:
        try:
            id2=int(row[0])
            name2 = row[1]
            class2 =  row[3]
        except ValueError:
            pass
        else:
            ids.append(id2)
            name.append(name2)
            classes.append(class2)
            counts.append(1)

filename3 = 'pythonsign_20181113.csv'
with open(filename3) as f3:
    reader = csv.reader(f3)
    for row in reader:
        try:
            id3=int(row[0])
            name3 = row[1]
            class3 =  row[3]
        except ValueError:
            pass
        else:
            ids.append(id3)
            name.append(name3)
            classes.append(class3)
            counts.append(1)
#将几个列表叠加在一个列表之间
##name = []
##for nm1 in names1:
##    name.append(nm1)
##for nm2 in names2:
##    name.append(nm2)
##for nm3 in names3:
##    name.append(nm3)
##print(name)
name_real = []
#将表中重复的东西删掉
for nm in name:
    if nm not in name_real:
        name_real.append(nm)
    else:
        continue
#数一下每一个人签到的次数
frequencies = []
for value in name:
    frequency = name.count(value)
    frequencies.append(frequency)
print(frequencies)
#画出签到的散点图
x_values = name
y_values = frequencies
plt.scatter(x_values,y_values,s=1)
plt.show()

##filenames = 'frequency.csv'
##with open(filenames,'w') as fs:
##    writer = csv.writer(fs)
##    writer.writerow(['学号','姓名','班级','签到次数'])

filename="frequencies.txt"
with open(filename,'w') as f:
    f.write("%s %15s %6s %4s"%("学号","姓名","签到次数","班级")+"\n") #指定占位符宽度   
    for i in range(len(ids)):
        f.write("%10d %3s %6d %10s"%(ids[i],name[i],frequencies[i],classes[i])+"\n")

        
